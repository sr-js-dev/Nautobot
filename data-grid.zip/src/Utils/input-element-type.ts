export enum InputElementType {
  TextField = 'text-field',
  Select = 'select',
  Textarea = 'textarea',
  Autocomplete = 'autocomplete',
}
