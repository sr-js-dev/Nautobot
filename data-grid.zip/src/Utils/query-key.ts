export const QueryKeys = {
  GET_TABLE_DATA: 'GET_TABLE_DATA',
};
