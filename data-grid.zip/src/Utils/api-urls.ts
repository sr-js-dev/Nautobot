export const API_URLS = {
  GET_TABLE_DATA: 'ipam/ip-addresses/',
};
