export interface CardProps {
  cardName: string;
  children: React.ReactNode;
}
