export interface AssignedUser {
  user_id: number
  email: string
  first_name: string
  last_name: string
  role: string
  last_login: string
}
