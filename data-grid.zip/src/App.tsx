import { IpAddress } from './Pages'

function App() {
  return (
    <><IpAddress /></>
  );
}

export default App;
